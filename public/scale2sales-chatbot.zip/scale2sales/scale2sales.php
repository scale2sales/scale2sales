<?php
/**
 * Plugin Name: Scale2Sales AI Chatbot
 * Plugin URI: https://scale2sales.com
 * Description: Add an AI chatbot trained on your website content in minutes. No coding required.
 * Version: 1.0.0
 * Author: Scale2Sales
 * Author URI: https://scale2sales.com
 * License: GPL v2 or later
 * Text Domain: scale2sales
 */

if (!defined('ABSPATH')) exit;

// Define constants
define('SCALE2SALES_VERSION', '1.0.0');
define('SCALE2SALES_PLUGIN_URL', plugin_dir_url(__FILE__));
define('SCALE2SALES_PLUGIN_PATH', plugin_dir_path(__FILE__));

// Add settings menu
add_action('admin_menu', 'scale2sales_add_menu');
function scale2sales_add_menu() {
    add_options_page(
        'Scale2Sales AI Chatbot',
        'Scale2Sales',
        'manage_options',
        'scale2sales',
        'scale2sales_settings_page'
    );
}

// Register settings
add_action('admin_init', 'scale2sales_register_settings');
function scale2sales_register_settings() {
    register_setting('scale2sales_settings', 'scale2sales_project_id', array(
        'sanitize_callback' => 'sanitize_text_field',
    ));
    register_setting('scale2sales_settings', 'scale2sales_widget_name', array(
        'sanitize_callback' => 'sanitize_text_field',
    ));
    register_setting('scale2sales_settings', 'scale2sales_greeting', array(
        'sanitize_callback' => 'sanitize_text_field',
    ));
    register_setting('scale2sales_settings', 'scale2sales_color', array(
        'sanitize_callback' => 'sanitize_hex_color',
    ));
    register_setting('scale2sales_settings', 'scale2sales_position', array(
        'sanitize_callback' => 'sanitize_text_field',
    ));
    register_setting('scale2sales_settings', 'scale2sales_enabled', array(
        'sanitize_callback' => 'absint',
    ));
}

// Settings page HTML
function scale2sales_settings_page() {
    $project_id = get_option('scale2sales_project_id', '');
    $widget_name = get_option('scale2sales_widget_name', 'AI Assistant');
    $greeting = get_option('scale2sales_greeting', 'Hi! How can I help you today?');
    $color = get_option('scale2sales_color', '#6366f1');
    $position = get_option('scale2sales_position', 'right');
    $enabled = get_option('scale2sales_enabled', 1);
    ?>
    <div class="wrap">
        <div style="display:flex;align-items:center;gap:12px;margin-bottom:24px;padding:20px;background:#fff;border:1px solid #e5e7eb;border-radius:12px;">
            <div style="width:40px;height:40px;background:#6366f1;border-radius:8px;display:flex;align-items:center;justify-content:center;">
                <svg width="24" height="24" fill="white" viewBox="0 0 24 24">
                    <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 14.5v-9l6 4.5-6 4.5z"/>
                </svg>
            </div>
            <div>
                <h1 style="margin:0;font-size:20px;color:#111827;">Scale2Sales AI Chatbot</h1>
                <p style="margin:0;color:#6b7280;font-size:13px;">Add an AI chatbot trained on your website content</p>
            </div>
        </div>

        <?php if (isset($_GET['settings-updated'])): ?>
        <div class="notice notice-success is-dismissible">
            <p><strong>Settings saved!</strong> Your chatbot will appear on your website shortly.</p>
        </div>
        <?php endif; ?>

        <?php if (empty($project_id)): ?>
        <div class="notice notice-warning">
            <p>
                <strong>Get started:</strong> You need a Scale2Sales account and Project ID to use this plugin.
                <a href="https://scale2sales.com/signup" target="_blank" style="color:#6366f1;font-weight:600;">Create a free account</a>
            </p>
        </div>
        <?php endif; ?>

        <form method="post" action="options.php">
            <?php settings_fields('scale2sales_settings'); ?>

            <!-- Project ID -->
            <div style="background:#fff;border:1px solid #e5e7eb;border-radius:12px;padding:24px;margin-bottom:20px;">
                <h2 style="margin-top:0;font-size:16px;color:#111827;">1. Connect your chatbot</h2>
                <p style="color:#6b7280;font-size:13px;">Find your Project ID in your Scale2Sales dashboard under Projects > Embed.</p>

                <table class="form-table" style="margin-top:0;">
                    <tr>
                        <th style="width:160px;padding:8px 0;">
                            <label for="scale2sales_project_id" style="font-weight:600;">Project ID *</label>
                        </th>
                        <td>
                            <input
                                type="text"
                                id="scale2sales_project_id"
                                name="scale2sales_project_id"
                                value="<?php echo esc_attr($project_id); ?>"
                                placeholder="e.g. 015698d3-e98a-476b-9468-ba4a5a752ac5"
                                style="width:100%;max-width:420px;padding:8px 12px;border:1px solid #d1d5db;border-radius:8px;font-size:13px;"
                            />
                            <?php if (!empty($project_id)): ?>
                            <span style="color:#10b981;margin-left:8px;">✅ Connected</span>
                            <?php endif; ?>
                            <p class="description">
                                <a href="https://scale2sales.com/dashboard/projects" target="_blank" style="color:#6366f1;">
                                    Get your Project ID from your dashboard →
                                </a>
                            </p>
                        </td>
                    </tr>
                    <tr>
                        <th style="padding:8px 0;">
                            <label style="font-weight:600;">Enable chatbot</label>
                        </th>
                        <td>
                            <label style="display:flex;align-items:center;gap:8px;cursor:pointer;">
                                <input type="checkbox" name="scale2sales_enabled" value="1" <?php checked($enabled, 1); ?> />
                                <span style="font-size:13px;">Show chatbot on all pages</span>
                            </label>
                        </td>
                    </tr>
                </table>
            </div>

            <!-- Customize -->
            <div style="background:#fff;border:1px solid #e5e7eb;border-radius:12px;padding:24px;margin-bottom:20px;">
                <h2 style="margin-top:0;font-size:16px;color:#111827;">2. Customize your chatbot</h2>

                <table class="form-table" style="margin-top:0;">
                    <tr>
                        <th style="width:160px;padding:8px 0;">
                            <label for="scale2sales_widget_name" style="font-weight:600;">Chatbot name</label>
                        </th>
                        <td>
                            <input
                                type="text"
                                id="scale2sales_widget_name"
                                name="scale2sales_widget_name"
                                value="<?php echo esc_attr($widget_name); ?>"
                                placeholder="AI Assistant"
                                style="width:100%;max-width:300px;padding:8px 12px;border:1px solid #d1d5db;border-radius:8px;font-size:13px;"
                            />
                            <p class="description">The name shown in the chat header (e.g. "Sarah from Acme Support")</p>
                        </td>
                    </tr>
                    <tr>
                        <th style="padding:8px 0;">
                            <label for="scale2sales_greeting" style="font-weight:600;">Greeting message</label>
                        </th>
                        <td>
                            <input
                                type="text"
                                id="scale2sales_greeting"
                                name="scale2sales_greeting"
                                value="<?php echo esc_attr($greeting); ?>"
                                placeholder="Hi! How can I help you today?"
                                style="width:100%;max-width:420px;padding:8px 12px;border:1px solid #d1d5db;border-radius:8px;font-size:13px;"
                            />
                            <p class="description">First message visitors see when they open the chat</p>
                        </td>
                    </tr>
                    <tr>
                        <th style="padding:8px 0;">
                            <label for="scale2sales_color" style="font-weight:600;">Brand color</label>
                        </th>
                        <td style="display:flex;align-items:center;gap:12px;padding:8px 0;">
                            <input
                                type="color"
                                id="scale2sales_color"
                                name="scale2sales_color"
                                value="<?php echo esc_attr($color); ?>"
                                style="width:48px;height:38px;border:1px solid #d1d5db;border-radius:8px;cursor:pointer;padding:2px;"
                            />
                            <input
                                type="text"
                                value="<?php echo esc_attr($color); ?>"
                                id="scale2sales_color_text"
                                style="width:120px;padding:8px 12px;border:1px solid #d1d5db;border-radius:8px;font-size:13px;"
                                onchange="document.getElementById('scale2sales_color').value=this.value"
                            />
                        </td>
                    </tr>
                    <tr>
                        <th style="padding:8px 0;">
                            <label for="scale2sales_position" style="font-weight:600;">Widget position</label>
                        </th>
                        <td>
                            <select
                                id="scale2sales_position"
                                name="scale2sales_position"
                                style="padding:8px 12px;border:1px solid #d1d5db;border-radius:8px;font-size:13px;"
                            >
                                <option value="right" <?php selected($position, 'right'); ?>>Bottom right</option>
                                <option value="left" <?php selected($position, 'left'); ?>>Bottom left</option>
                            </select>
                        </td>
                    </tr>
                </table>
            </div>

            <!-- Preview -->
            <?php if (!empty($project_id)): ?>
            <div style="background:#f9fafb;border:1px solid #e5e7eb;border-radius:12px;padding:24px;margin-bottom:20px;">
                <h2 style="margin-top:0;font-size:16px;color:#111827;">3. Preview your chatbot</h2>
                <p style="color:#6b7280;font-size:13px;margin-bottom:12px;">Click the button below to preview how your chatbot looks.</p>
                <a
                    href="https://scale2sales.com/chat/<?php echo esc_attr($project_id); ?>"
                    target="_blank"
                    style="display:inline-flex;align-items:center;gap:8px;background:#6366f1;color:#fff;padding:10px 20px;border-radius:8px;text-decoration:none;font-size:13px;font-weight:600;"
                >
                    <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"/>
                    </svg>
                    Preview chatbot
                </a>
            </div>
            <?php endif; ?>

            <?php submit_button('Save settings', 'primary', 'submit', true, array('style' => 'background:#6366f1;border-color:#6366f1;padding:10px 24px;font-size:14px;border-radius:8px;height:auto;')); ?>
        </form>

        <!-- Help -->
        <div style="background:#eff6ff;border:1px solid #bfdbfe;border-radius:12px;padding:20px;margin-top:20px;">
            <h3 style="margin-top:0;color:#1e40af;font-size:14px;">Need help?</h3>
            <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:12px;">
                <a href="https://scale2sales.com/dashboard" target="_blank" style="color:#3b82f6;font-size:13px;">📊 Go to dashboard</a>
                <a href="https://scale2sales.com/dashboard/projects" target="_blank" style="color:#3b82f6;font-size:13px;">🔑 Get Project ID</a>
                <a href="mailto:support@scale2sales.com" style="color:#3b82f6;font-size:13px;">📧 Contact support</a>
            </div>
        </div>
    </div>

    <script>
    document.getElementById('scale2sales_color').addEventListener('input', function() {
        document.getElementById('scale2sales_color_text').value = this.value;
    });
    </script>
    <?php
}

// Inject widget script into footer
add_action('wp_footer', 'scale2sales_inject_widget');
function scale2sales_inject_widget() {
    $project_id = get_option('scale2sales_project_id', '');
    $enabled = get_option('scale2sales_enabled', 1);

    if (empty($project_id) || !$enabled) return;

    $widget_name = get_option('scale2sales_widget_name', 'AI Assistant');
    $greeting = get_option('scale2sales_greeting', 'Hi! How can I help you today?');
    $color = get_option('scale2sales_color', '#6366f1');
    $position = get_option('scale2sales_position', 'right');

    ?>
    <!-- Scale2Sales AI Chatbot -->
    <script>
        window.Scale2SalesConfig = {
            projectId: "<?php echo esc_js($project_id); ?>",
            appUrl: "https://scale2sales.com",
            primaryColor: "<?php echo esc_js($color); ?>",
            widgetName: "<?php echo esc_js($widget_name); ?>",
            greeting: "<?php echo esc_js($greeting); ?>",
            position: "<?php echo esc_js($position); ?>"
        };
    </script>
    <script src="https://scale2sales.com/widget.js" async></script>
    <?php
}

// Add settings link on plugins page
add_filter('plugin_action_links_' . plugin_basename(__FILE__), 'scale2sales_add_settings_link');
function scale2sales_add_settings_link($links) {
    $settings_link = '<a href="options-general.php?page=scale2sales" style="color:#6366f1;font-weight:600;">Settings</a>';
    array_unshift($links, $settings_link);
    return $links;
}

// Activation hook
register_activation_hook(__FILE__, 'scale2sales_activate');
function scale2sales_activate() {
    add_option('scale2sales_enabled', 1);
    add_option('scale2sales_widget_name', 'AI Assistant');
    add_option('scale2sales_greeting', 'Hi! How can I help you today?');
    add_option('scale2sales_color', '#6366f1');
    add_option('scale2sales_position', 'right');
}

// Deactivation hook
register_deactivation_hook(__FILE__, 'scale2sales_deactivate');
function scale2sales_deactivate() {
    // Nothing to clean up
}
