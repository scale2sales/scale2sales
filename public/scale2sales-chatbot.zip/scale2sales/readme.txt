=== Scale2Sales AI Chatbot ===
Contributors: scale2sales
Tags: chatbot, ai, customer support, live chat, artificial intelligence
Requires at least: 5.0
Tested up to: 6.4
Stable tag: 1.0.0
License: GPLv2 or later

Add an AI chatbot trained on your website content in minutes. No coding required.

== Description ==

Scale2Sales adds an intelligent AI chatbot to your WordPress website that is automatically trained on your website content.

= How it works =

1. Create a free account at scale2sales.com
2. Create a project and scan your website
3. Install this plugin and enter your Project ID
4. Your AI chatbot goes live instantly

= Features =

* AI trained on your website content automatically
* Answers customer questions 24/7
* Captures leads while you sleep
* Fully customizable colors, name, and greeting
* Works on any WordPress theme
* No coding required

== Installation ==

1. Download the plugin zip file from scale2sales.com
2. Go to WordPress Admin > Plugins > Add New > Upload Plugin
3. Upload the zip file and click Install Now
4. Click Activate Plugin
5. Go to Settings > Scale2Sales
6. Enter your Project ID from your Scale2Sales dashboard
7. Click Save -- your chatbot is now live!

== Frequently Asked Questions ==

= Where do I get my Project ID? =
Log into scale2sales.com, go to Projects, click on your project, then click Embed. Your Project ID is shown there.

= Is it free? =
Scale2Sales offers a free plan with 50 messages per month. Paid plans start at $29/month.

= Will it slow down my website? =
No -- the widget loads asynchronously and has no impact on page load speed.

== Changelog ==

= 1.0.0 =
* Initial release
